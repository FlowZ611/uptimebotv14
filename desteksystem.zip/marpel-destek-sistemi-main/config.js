module.exports = {
    token: "",
    prefix: "",
    content: "",
    channel: "",
    button: "",
    yetkili: "",
    log: ""
}
